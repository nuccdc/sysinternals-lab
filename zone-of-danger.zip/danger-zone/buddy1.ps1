While ($TRUE) {
	$buddy = Get-WmiObject Win32_Process -Filter "Name='powershell.exe' AND CommandLine LIKE '%buddy2.ps1%'"
	if ($buddy) {
		"Buddy 1: Buddy running"
	}
	else {
		"Buddy 1: Buddy not running"
		start-process powershell C:\Users\Helena\Desktop\buddy2.ps1 -WindowStyle Hidden
	}
	sleep 1
}