While ($TRUE) {
	$buddy = Get-WmiObject Win32_Process -Filter "Name='powershell.exe' AND CommandLine LIKE '%buddy1.ps1%'"
	if ($buddy) {
		"Buddy 2: Buddy running"
	}
	else {
		"Buddy 2: Buddy not running"
		start-process powershell C:\Users\Helena\Desktop\buddy1.ps1 -WindowStyle Hidden
	}
	sleep 1
}